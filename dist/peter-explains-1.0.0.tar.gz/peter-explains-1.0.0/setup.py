from setuptools import setup, find_packages

setup(
    name="peter-explains",
    version="1.0.0",
    description="Linux command explanations from Peter Griffin",
    author="Atick Faisal",
    author_email="atickfaisal@gmail.com",
    packages=find_packages(),
    install_requires=[],
)
